//date....2023.1.9

void main(){


int ramAge = 20;

int samirAge  = ramAge --; 


print("samirAge");
print("ramAge");


}