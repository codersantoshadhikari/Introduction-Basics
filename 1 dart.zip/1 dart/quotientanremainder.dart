//Write a program to find quotient and remainder of two integers.
//int n1 = 10;
//int n2 = 3;

//int q = n1... n2;
//int r = n1... n2;

//print("The quotent is $q")
//print("The remainder is $r)


void main() {
  int n1 = 10;
  int n2 = 3;

  int q = n1 ~/ n2;  
  int r = n1 % n2;  

  print("The quotient is $q"); 
  print("The remainder is $r");  
}
