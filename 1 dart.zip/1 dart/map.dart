//date....2023.1.9
void main(){

//  my Weekly expenses

  Map<String, double> wE ={
"sunday": 500,
"monday":100,
"tuesday":100,
"wednesday":200,
"thursday":2001,
"firday":100,
"saturday": 110,
  };

  // Total Calculation
 double total = wE["sunday"]! +wE["monday"]!+wE["tuesday"]!+wE["wednesday"]!+wE["thursday"]!+ wE["firday"]!+ wE["saturday"]!;
// Display Result
 print("Total is $total");
}