
//date....2023.1.9
void main(){

int age = 10;
print(age++);
print(--age);


}