//Suppose, you often go to restaurant with friends and you have to split amount of bill. Write a program to calculate split amount of bill. Formula= (total bill amount) / number of people
// date....2023.1.10
void main() {
  // Total bill and number of people
  num totalBill = 2000;
  int numPeople = 5;

  // Calculate the amount each person should pay
  num amountPerPerson = splitBill(totalBill, numPeople);

  // Print the result
  print('Each person should pay: $amountPerPerson');
}

//  split bill amount
num splitBill(num total, int numPeople) {
  return total / numPeople;
}


