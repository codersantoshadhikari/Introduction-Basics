void main(){

print('Hello I am "Santosh Adhikari"');
print("Hello I'am \"Santosh Adhikari\"");



print("""  

Santosh Adhikary'

""");

}