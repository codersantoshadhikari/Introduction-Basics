void main(){
var n1 = 100;
var n2 = 3;
var sum  = n1 + n2;
var diff = n1 - n2;
var div  = n1 / n2;

 
 print("sum is $sum");
 print("diff is $diff");
 print("div is $diff ");

 
  
}