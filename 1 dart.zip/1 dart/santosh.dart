void main(){

print("Santosh Adhikari");

}