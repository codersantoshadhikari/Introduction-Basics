import 'dart:async';
import 'dart:convert';


class LoginBloc {
  final _emailController = StreamController<String>();
  final _passwordController = StreamController<String>();
  final _isLoadingController = StreamController<bool>();
  final _isLoggedInController = StreamController<bool>();

  Stream<String> get email => _emailController.stream;
  Stream<String> get password => _passwordController.stream;
  Stream<bool> get isLoading => _isLoadingController.stream;
  Stream<bool> get isLoggedIn => _isLoggedInController.stream;

  Function(String) get changeEmail => _emailController.sink.add;
  Function(String) get changePassword => _passwordController.sink.add;

  Future<void> login() async {
    _isLoadingController.sink.add(true);
    try {
      // Perform login request to server
      final response = await _withClient((client) =>
        client.post("""
https://yourserver.com/login""", headers: null, body: null, encoding: null));

      if (response.statusCode == 200) {
        // parse the response and handle it
        final Map<String, dynamic> json = jsonDecode(response.body);
        if(json["status"] == "success"){
          _isLoggedInController.sink.add(true);
        }else{
          _isLoggedInController.sink.add(false);
          throw Exception(json["message"]);
        }
        _isLoadingController.sink.add(false);
      } else {
        _isLoadingController.sink.add(false);
        throw Exception('Login Failed');
      }
    } catch (e) {
      _isLoadingController.sink.add(false);
      throw e;
    }
  }

  void dispose() {
    _emailController.close();
    _passwordController.close();
    _isLoadingController.close();
    _isLoggedInController.close();
  }
}

_withClient(Function(dynamic client) param0) {
}

