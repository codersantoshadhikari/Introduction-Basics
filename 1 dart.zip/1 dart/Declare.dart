//Declare constant type of int set value 7.

void main() {
  const int myConstant = 7;
  print(myConstant);  
}