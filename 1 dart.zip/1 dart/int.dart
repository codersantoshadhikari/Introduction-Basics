//date....2023.1.9

void main(){

int age = 30;
age++;
age--;
print(age); 
}
