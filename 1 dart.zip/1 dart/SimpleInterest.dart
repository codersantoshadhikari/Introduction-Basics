void main(){

var Principal = 50;
var Time = 3;
var Rate = 2;
var SimpleInterest = ( Principal*Time*Rate )/100;
print("SimpleInterest is:  $SimpleInterest");
}