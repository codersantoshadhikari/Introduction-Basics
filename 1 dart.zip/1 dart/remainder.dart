//Write a program to find quotient and remainder of two integers.
//date....2023.1.9

void main() {
  int num = 7;
  int den = 3;

  int quotient = num ~/ den;
  int remainder = num % den;

  print("Quotient: $quotient");
  print("Remainder: $remainder");
}
