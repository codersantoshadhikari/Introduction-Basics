void main() {
 
  double num1 = double.parse("100");
  double num2 = 50.toDouble();
  double sum = num1 + num2;
  print(sum);
}
