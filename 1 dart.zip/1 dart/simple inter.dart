void main(){

}