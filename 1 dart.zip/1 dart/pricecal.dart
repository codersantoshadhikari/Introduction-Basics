void main(){


  in totalPerson = 3;
  double billAnount = 500;
  double individu



  int n1 = 10;
  int n2 = 20;
  print(n1~/n2);

}